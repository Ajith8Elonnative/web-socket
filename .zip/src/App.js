import React, { useState, useEffect } from 'react';
import {
  TextField,
  IconButton,
  List,
  ListItem,
  ListItemText,
  ListItemAvatar,
  Avatar,
  Typography,
  CircularProgress,
} from '@mui/material';
import Stomp from 'stompjs';
import SockJS from 'sockjs-client';
import axios from 'axios'

const App = () => {
  const [messages, setMessages] = useState([]);
  const [message, setMessage] = useState('');
  const [nickname, setNickname] = useState('');
  const [stompClient, setStompClient] = useState(null);
  const [isConnected, setIsConnected] = useState(false);
  const [loading, setLoading] = useState(true);

  // Send message logic
  const sendMessage = () => {
    const trimmedNickname = nickname.trim() || 'Anonymous'; // Default to 'Anonymous' if nickname is empty

    if (message.trim() && trimmedNickname && stompClient && stompClient.connected) {
      const chatMessage = {
        nickname: trimmedNickname, // Use validated nickname here
        content: message,
      };
      // Make a POST request to send the message
      axios.post('http://localhost:8080/chat/create', chatMessage)
        .then((response) => {
          // Handle success response if needed
          console.log('Message sent successfully:', response.data);

          setMessage(''); // Clear the message input after sending
        })
        .catch((error) => {
          // Handle error if the request fails
          console.error('Error sending message:', error);
        });
      getChat()
      stompClient.send('/app/chat', {}, JSON.stringify(chatMessage));
      setMessage('');
    }
  };

  // WebSocket connection
  useEffect(() => {
    const socket = new SockJS('http://localhost:8080/ws');
    const client = Stomp.over(socket);

    client.connect({}, () => {
      setIsConnected(true);
      setLoading(false);
      client.subscribe('/topic/messages', (message) => {
        const receivedMessage = JSON.parse(message.body);
        setMessages((prevMessages) => [...prevMessages, receivedMessage]);
      });
    }, (error) => {
      console.error('Error connecting to WebSocket:', error);
      setLoading(false);
    });
    setStompClient(client);

    // Cleanup WebSocket connection when component unmounts
    return () => {
      if (client && client.connected) {
        client.disconnect();
      }
    };
  }, []); // Empty dependency array ensures this effect runs only once (on mount)

  const handleNicknameChange = (event) => {
    setNickname(event.target.value);
  };

  const handleMessageChange = (event) => {
    setMessage(event.target.value);
  };

  // Check nickname before sending a message
  const handleSendMessage = () => {
    if (!nickname.trim()) {
      alert('Please enter a nickname');
      return;
    }
    sendMessage();
  };

  const getChat = () => {
    // Make a POST request to send the message
    axios.get('http://localhost:8080/chat/getAll')
      .then((response) => {
        // Handle success response if needed
        console.log('data fetch successfully:', response.data);
      })
      .catch((error) => {
        // Handle error if the request fails
        console.error('Error sending message:', error);
      });
  }

  return (
    <div>
      {loading && (
        <div style={{ textAlign: 'center', marginTop: '50px' }}>
          <CircularProgress />
          <Typography variant="h6">Connecting...</Typography>
        </div>
      )}

      {!loading && !isConnected && (
        <Typography variant="h6" color="error" align="center">
          Failed to connect to WebSocket.
        </Typography>
      )}

      <List>
        {messages.map((msg, index) => (
          <ListItem key={index}>
            <ListItemAvatar>
              <Avatar>{nickname.charAt(0).toUpperCase()}</Avatar>
              {/* Display first letter of nickname */}
            </ListItemAvatar>
            <ListItemText
              primary={<Typography variant="subtitle1">{nickname}</Typography>}
              secondary={msg.content}
            />
          </ListItem>
        ))}
      </List>

      <div style={{ display: 'flex', alignItems: 'center' }}>
        <TextField
          placeholder="Enter your nickname"
          value={nickname}
          onChange={handleNicknameChange}
          autoFocus
          disabled={loading || !isConnected}
          fullWidth
        />
        <TextField
          placeholder="Type a message"
          value={message}
          onChange={handleMessageChange}
          fullWidth
          disabled={loading || !isConnected || !nickname}
        />
        <IconButton
          onClick={handleSendMessage}
          disabled={!message.trim() || !nickname.trim() || !isConnected}
        >
          Send
        </IconButton>
      </div>
    </div>
  );
};

export default App;
